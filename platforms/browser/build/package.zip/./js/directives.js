'use strict';
var diabetesDirectives = angular.module('diabetesDirectives', []);
/* Directives */
